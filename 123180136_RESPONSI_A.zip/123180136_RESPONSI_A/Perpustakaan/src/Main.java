import MVC.HomeMVC;

public class Main {
    public static void main(String[] args) {
        HomeMVC homeMvc = new HomeMVC();
    }
}
